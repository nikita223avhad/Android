package com.example.recycleviewpracproduct;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class LaptopAdapter extends RecyclerView.Adapter<LaptopAdapter.LaptopViewHolder> implements Filterable {

    Context context;
    private List<Laptops> laptopsList;
    private ArrayList<Laptops> exampleListFull;


    public LaptopAdapter(Context context, List<Laptops> laptopsList){
        this.context = context;
        this.laptopsList = laptopsList;
        this.exampleListFull = new ArrayList<>(laptopsList);
    }




    @NonNull
    @Override
    public LaptopViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {//

        LayoutInflater layoutInflater = LayoutInflater.from(context);//
        View view = layoutInflater.inflate(R.layout.laptop_item,null);//
        return new LaptopViewHolder(view);
    }

    public void onBindViewHolder (LaptopViewHolder holder, int position){
        Laptops laptops = laptopsList.get(position);

        holder.imageView.setImageResource(laptops.getImage());
        holder.textViewTitle.setText(laptops.getTitle());
        holder.textViewDescrip.setText(laptops.getDescrip());
        holder.textViewRating.setText(String.valueOf(laptops.getRating()));
        holder.textViewPrice.setText(String.valueOf(laptops.getPrice()));

    }
    public int getItemCount(){ return laptopsList.size();}

    @Override
    public Filter getFilter() {
        return exampleFilter;
    }
    private Filter exampleFilter = new Filter() {
        //run on backgraund tread
        @SuppressLint("NewApi")
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<Laptops> filteredlist = new ArrayList<>();

            if(constraint.toString().isEmpty()){
                filteredlist.addAll(exampleListFull);
            }else {
                for (Laptops item : laptopsList) {
                    if (item.getTitle().toLowerCase().contains(constraint.toString().toLowerCase())) {
                        filteredlist.add(item);
                    }

                }
            }

           if (constraint == null || constraint.length() == 0) {

                filteredlist.addAll(exampleListFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (Laptops item : exampleListFull) {
                    if (item.getTitle().toLowerCase().contains(filterPattern)) {
                        filteredlist.add(item);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredlist;

            return results;
        }


        //run on UI thread
        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            laptopsList.clear();
            laptopsList.addAll((ArrayList<Laptops>) filterResults.values);
            notifyDataSetChanged();




        }


    };

    public void filterList(ArrayList<Laptops> filteredlist) {
        laptopsList = filteredlist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }


    public class LaptopViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textViewTitle, textViewDescrip, textViewRating, textViewPrice;

        public LaptopViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            textViewTitle = itemView.findViewById(R.id.TV_Title);
            textViewDescrip = itemView.findViewById(R.id.TV_Descrip);
            textViewRating = itemView.findViewById(R.id.TV_Rating);
            textViewPrice = itemView.findViewById(R.id.TV_Price);
        }


    }

}



