package com.example.recycleviewpracproduct;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.SearchManager;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.inputmethod.EditorInfo;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    LaptopAdapter adapter;
    List<Laptops> laptopsList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(linearLayoutManager);

        laptopsList = new  ArrayList<>();
        laptopsList.add(new Laptops(1,"Apple MacBook Air Core i5 5th Gen _(8GB/128GB SSD/Mac OS Sierra)", "13.3 Inch, 256GB",4.3, 60000, R.drawable.macbook ));
        laptopsList.add(new Laptops(1,"Dell Inspiron 7000 Core i5 7th Gen - (8 GB/1 TB HDD/Windows 10 Home)","14 inch, Gray, 1.659 kg", 4.3,60000,  R.drawable.dellinspiron));
        laptopsList.add(new Laptops(1, "Microsoft Surface Pro 4 Core m3 6th Gen - (4 GB/128 GB SSD/Windows 10)","13.3 inch, Silver, 1.35 kg",4.3,6000, R.drawable.surface));
            laptopsList.add(new Laptops(1,"Apple MacBook Air Core i5 5th Gen _(8GB/128GB SSD/Mac OS Sierra)", "13.3 Inch, 256GB",4.3, 60000, R.drawable.macbook ));
        laptopsList.add(new Laptops(1,"Dell Inspiron 7000 Core i5 7th Gen - (8 GB/1 TB HDD/Windows 10 Home)","14 inch, Gray, 1.659 kg", 4.3,60000,  R.drawable.dellinspiron));
        laptopsList.add(new Laptops(1, "Microsoft Surface Pro 4 Core m3 6th Gen - (4 GB/128 GB SSD/Windows 10)","13.3 inch, Silver, 1.35 kg",4.3,6000, R.drawable.surface));
        laptopsList.add(new Laptops(1,"Apple MacBook Air Core i5 5th Gen _(8GB/128GB SSD/Mac OS Sierra)", "13.3 Inch, 256GB",4.3, 60000, R.drawable.macbook ));
        laptopsList.add(new Laptops(1,"Dell Inspiron 7000 Core i5 7th Gen - (8 GB/1 TB HDD/Windows 10 Home)","14 inch, Gray, 1.659 kg", 4.3,60000,  R.drawable.dellinspiron));
        laptopsList.add(new Laptops(1, "Microsoft Surface Pro 4 Core m3 6th Gen - (4 GB/128 GB SSD/Windows 10)","13.3 inch, Silver, 1.35 kg",4.3,6000, R.drawable.surface));

       adapter=new LaptopAdapter(this,laptopsList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
       // recyclerView.setAdapter(new LaptopAdapter(getApplicationContext(),laptopsList));


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
       SearchView searchView= (SearchView) MenuItemCompat.getActionView(searchItem);
       searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);
       searchView.setIconifiedByDefault(true);
       SearchManager manager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return false;
            }
        });
        return true;

    }
    private void filter(String text) {
        // creating a new array list to filter our data.
        ArrayList<Laptops> filteredlist = new ArrayList<Laptops>();

        // running a for loop to compare elements.
        for (Laptops item : laptopsList) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.getTitle().toLowerCase().contains(text.toLowerCase())) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(item);
            }
        }
        if (filteredlist.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(this, "No Data Found..", Toast.LENGTH_SHORT).show();
        } else {
            // at last we are passing that filtered
            // list to our adapter class.
            adapter.filterList(filteredlist);
        }
    }


}